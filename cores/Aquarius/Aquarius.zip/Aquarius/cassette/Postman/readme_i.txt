Requires 16K expander

In 'Happy-Happy' land everybody lives in gaily coloured houses and has 
a lovely time all the time, except Postman Pot.
  Every morning he picks up his bag of letters and sets off to post 
them but on the corner of Chocolate Street is a big bad dog which bites 
him and Pot has to go to the hospital and doesn't deliver any letters.
  Next day Pot goes round the backs of the houses and tries to deliver 
his letters but three dogs chase him. Pot runs down the street, across 
the road and gets run over by a car.
  Pot the next day avoids the dogs, avoids the cars, delivers his 
letters, goes back to the post-office and is given parcels to deliver. He 
then has more dogs and more cars to contend with.
  Postman Pot is a fun maze/strategy game that all the family can play. 
With progressively harder and harder screens. A full hall of fame and 
high score table. Postman Pot will keep you engrossed for hours.
